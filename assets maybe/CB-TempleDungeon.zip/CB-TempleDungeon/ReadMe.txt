Thanks for downloading Colin Brown's Pixel Tileset: Temple / Dungeon

##Contents:
CB-Cover.png
CB-All_Temple.png
CB-Temple-A.png
CB-Temple-B.png
CB-Temple-C.png
CB-Temple-D.png
CB-Temple-E.png
Example.png

Take a look at the Example.png provided to better undertstand the possibilities of the Tileset.
And feel free to share what you make with these tools! Tagging my profiles on social media posts 
is greatly appreciated.

##Find me online:
brownillustration.com
Instagram & Twitter: @ColinBrown_
Tumblr: http://brownillustration.tumblr.com/
Streaming on TWITCH.tv: https://www.twitch.tv/brainlobster

Thanks again,
-Colin
